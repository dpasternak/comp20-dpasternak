
/**
 * Module dependencies.
 */

var express = require('express');
var routes = require('./routes');
var user = require('./routes/user');
var http = require('http');
var path = require('path');

var mongo = require('mongoskin');
var db = mongo.db("mongodb://localhost:27017/highscores", {native_parser:true});


var app = express();

// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.json());
app.use(express.urlencoded());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}


app.get('/', function(req,res) {
    res.render('index', { title: '2048 Game Center' });
  }
);


app.get('/scores.json', function(req, res) {
      res.header("Access-Control-Allow-Origin", "*");
      res.header("Access-Control-Allow-Headers", "X-Requested-With");
      //console.log(req.getParameter("username"));
      console.log(req.query);
      if(req.query.username) {
         db.collection('scores').find({'username':req.query.username}).sort({"score":-1}).toArray(function (err, items) {
           res.json(items);
         })
      } else {
        db.collection('scores').find().sort({"score":-1}).toArray(function (err, items) {
        res.json(items);
        })
      }
});

app.post('/submit.json', function(req, res) {
      res.header("Access-Control-Allow-Origin", "*");
      res.header("Access-Control-Allow-Headers", "X-Requested-With");
      if(req.body.username && req.body.score && req.body.grid)
      {
         db.collection('scores').insert(req.body, function(err, result) {
           res.send(
             (err == null) ? {msg: ''} : {msg:err}
           );
         }) ; 
 
      }
});   

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});
